# OOAD-mohamedbenhammadi-2021


## Applicatie voor leden zonder login
* De app kan zonder login inloggen en items bekijken, details van de item terug vinden door op de item te druken, kan nog zien hoeveel items nog aanwezig zijn door te zoeken.

## Applicatie voor leden met login
* De lid kan zijn items reservern en ontlenen, een overzicht van zijn geserveerde exemplaren bekijken en ontleningen, de lid kan ook zijn reservatie en ontleningen terugbrengen of annuleren, Lid kan ook zijn eventuele boete zien.

## Applicatie voor baliemedewerker
* De medewerker kan de items bekijken/toevoegen /aanpassen en verwijderen, 
* De medewerker kan de ontleningen en reservaties bekijken en annuleren door een lidnummer op te zoeken, kan ook de lidkaart vernieuwen, en boetes kwijschelden. De medewerker kan alle klanten zien, aanpassen, verwijderen, toevoegen. 


