﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmpClassLibrary
{
    public class Tijdschrift
    {
        static string connString = ConfigurationManager.AppSettings["connString"];


        //public int 

    }
}
